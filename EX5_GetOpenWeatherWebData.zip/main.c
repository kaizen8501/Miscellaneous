#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "stm32f10x.h"
#include "pltfrm_usart.h"

#define SSID 		"wizohp"
#define PASSWORD	"wiznet218"
#define SERVER_PORT	"80"
#define SERVER_IP	"128.199.164.95"
#define WEATHER_QUERY	"GET /data/2.5/weather?q=Seoul HTTP/1.1\r\nHost: api.openweathermap.org\r\n\r\n"


int main()
{
	char cmd[256];
	char recv_data[256];
	int32_t idx=0,is_response_ended=0;
	int32_t uart_recv;
	int32_t is_connected=0;

	platform_init();

	WizFi250_Restart();

	if ( send_and_check_command("AT+WLEAVE", 1, 500,  10, "[OK]", "", 1) !=0 )	{ printf("DBG>>> Error : AT Command\r\n");}
	if ( send_and_check_command("AT+WNET=1", 1, 500,  10, "[OK]", "", 1) !=0 )	{ printf("DBG>>> Error : AT Command\r\n");}


	sprintf(cmd,"AT+WSET=0,%s",SSID);
	if ( send_and_check_command(cmd, 1, 500,  10, "[OK]", "", 1) !=0 )			{ printf("DBG>>> Error : AT Command\r\n");}
	sprintf(cmd,"AT+WSEC=0,,%s",PASSWORD);
	if ( send_and_check_command(cmd, 1, 500,  10, "[OK]", "", 1) !=0 )			{ printf("DBG>>> Error : AT Command\r\n");}
	if ( send_and_check_command("AT+WJOIN", 1, 500,  100, "[OK]", "", 1) !=0 )	{ printf("DBG>>> Error : AT Command\r\n");}

	pltfrm_gpio_init(GPIOA,(GPIO_Pin_0 | GPIO_Pin_1),GPIO_Mode_Out_PP);
	pltfrm_gpio_set(GPIOA,(GPIO_Pin_0 | GPIO_Pin_1),1);

	while(1)
	{
		if(is_connected == 0)
		{
			sprintf(cmd,"AT+SCON=O,TCN,%s,%s,,1",SERVER_IP,SERVER_PORT);
			if ( send_and_check_command(cmd, 1, 500,  100, "[OK]", "[CONNECT", 1) !=0 )			{ printf("DBG>>> Error : AT Command\r\n"); break;}

			is_connected = 1;
			usart_puts(PF_USART1,"Send Query\r\n",strlen("Send Query\r\n"));
			usart_puts(PF_USART2,WEATHER_QUERY,strlen(WEATHER_QUERY));
		}
		else
		{
			while(1)
			{
				if( (uart_recv = usart_getc_nonblk(PF_USART2)) == RET_NOK )	continue;
				if((is_response_ended == 1) && (uart_recv == '\n'))
				{
					is_response_ended=0;
					break;
				}
				if( uart_recv == '\n')
				{
					is_response_ended++;
				}

				usart_putc(PF_USART1,uart_recv);
			}


			delay_ms(1000);
		}
	}
}
