#include "pltfrm_usart.h"

#include <sys/stat.h>
__attribute__ ((used))  int _write (int fd, char *ptr, int len)
{
  size_t i;
  for (i=0; i<len;i++) {
	  usart_putc(PF_USART1,ptr[i]); // call character output function
    }
  return len;
}


#if (USART1_RX_INTERRUPT == VAL_ENABLE)
	#define U1RX_BUF_SIZE		1024
	uint8_t  u1rx_buf[U1RX_BUF_SIZE];
	uint16_t u1rx_wr=0, u1rx_rd=0;
	void USART1_IRQHandler(void)	// USART1 ISR
	{
		if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET) {
			USART_ClearITPendingBit(USART1, USART_IT_RXNE);
			if( (u1rx_wr > u1rx_rd && u1rx_wr-u1rx_rd >= U1RX_BUF_SIZE-1) ||
				(u1rx_wr < u1rx_rd && u1rx_rd == u1rx_wr+1) )	// Buffer Overflow
			{
				USART_SendData(USART1, (uint8_t)'@');
				return;
			}
			u1rx_buf[u1rx_wr] = (uint8_t)USART_ReceiveData(USART1);
			if(u1rx_wr < U1RX_BUF_SIZE-1) u1rx_wr++;
			else u1rx_wr = 0;
		}
	}
#endif

#if (USART2_RX_INTERRUPT == VAL_ENABLE)
	#define U2RX_BUF_SIZE		1024
	uint8_t  u2rx_buf[U2RX_BUF_SIZE];
	uint16_t u2rx_wr=0, u2rx_rd=0;
	void USART2_IRQHandler(void)	// USART2 ISR
	{
		if(USART_GetITStatus(USART2, USART_IT_RXNE) != RESET) {
			USART_ClearITPendingBit(USART2, USART_IT_RXNE);
			if( (u2rx_wr > u2rx_rd && u2rx_wr-u2rx_rd >= U2RX_BUF_SIZE-1) ||
				(u2rx_wr < u2rx_rd && u2rx_rd == u2rx_wr+1) )	// Buffer Overflow
			{
				USART_SendData(USART1, (uint8_t)'!');
				return;
			}
			u2rx_buf[u2rx_wr] = (uint8_t)USART_ReceiveData(USART2);
			if(u2rx_wr < U2RX_BUF_SIZE-1) u2rx_wr++;
			else u2rx_wr = 0;
		}
	}
#endif


uint8_t usart_init(platform_usart usart)
{
	USART_TypeDef *usartx;
	USART_InitTypeDef USART_InitStructure;

	switch(usart)
	{
	case PF_USART1:
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
		pltfrm_gpio_init(USART1_PORT, USART1_TX_PIN, GPIO_Mode_AF_PP);
		pltfrm_gpio_init(USART1_PORT, USART1_RX_PIN, GPIO_Mode_IN_FLOATING);
		//pltfrm_gpio_init(USART1_PORT, USART1_RTS_PIN, GPIO_Mode_AF_PP);
		//pltfrm_gpio_init(USART1_PORT, USART1_CTS_PIN, GPIO_Mode_IN_FLOATING);

#if (USART1_RX_INTERRUPT == VAL_ENABLE)
		{
			NVIC_InitTypeDef NVIC_InitStructure;
			NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
			NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
			NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
			NVIC_Init(&NVIC_InitStructure);
		}
#endif
		usartx = USART1;
		break;
	case PF_USART2:
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
		pltfrm_gpio_init(USART2_PORT, USART2_TX_PIN, GPIO_Mode_AF_PP);
		pltfrm_gpio_init(USART2_PORT, USART2_RX_PIN, GPIO_Mode_IN_FLOATING);
		//pltfrm_gpio_init(USART2_PORT, USART2_RTS_PIN, GPIO_Mode_AF_PP);
		//pltfrm_gpio_init(USART2_PORT, USART2_CTS_PIN, GPIO_Mode_IN_FLOATING);

#if (USART2_RX_INTERRUPT == VAL_ENABLE)
		{
			NVIC_InitTypeDef NVIC_InitStructure;
			NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
			NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
			NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
			NVIC_Init(&NVIC_InitStructure);
		}
#endif
		usartx = USART2;
		break;
	default:
		return RET_NOK;
	}
	USART_Cmd(usartx, DISABLE);
	USART_InitStructure.USART_BaudRate		= 115200;
	USART_InitStructure.USART_WordLength	= USART_WordLength_8b;
	USART_InitStructure.USART_StopBits		= USART_StopBits_1;
	USART_InitStructure.USART_Parity		= USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl	= USART_HardwareFlowControl_None;

	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_Init(usartx, &USART_InitStructure);

#if (USART1_RX_INTERRUPT == VAL_ENABLE)
	USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
#endif

#if (USART2_RX_INTERRUPT == VAL_ENABLE)
	USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
#endif

	USART_Cmd(usartx, ENABLE);

	return RET_OK;
}


int usart_putc(platform_usart usart, int ch)
{
	switch(usart)
	{
	case PF_USART1:
		USART_SendData(USART1, (uint8_t)ch);
		while(USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
		break;
	case PF_USART2:
		USART_SendData(USART2, (uint8_t)ch);
		while(USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);
		break;
	default:
		return RET_NOK;
	}

	return ch;
}

int32_t usart_puts (platform_usart usart, uint8_t* buf, uint8_t reqSize)
{
	uint16_t lentot = 0;

	switch(usart)
	{
	case PF_USART1:
		while(*buf != '\0' && lentot<reqSize){
			usart_putc(PF_USART1, *buf);
			buf++;
			lentot++;
		}
		break;
	case PF_USART2:
		while(*buf != '\0' && lentot<reqSize){
			usart_putc(PF_USART2, *buf);
			buf++;
			lentot++;
		}
		break;
	default:
		return RET_NOK;
	}

	return lentot;
}



int usart_getc(platform_usart usart)
{
	switch(usart)
	{
		case PF_USART1:
#if (USART1_RX_INTERRUPT == VAL_ENABLE)
		{
			while(u1rx_rd == u1rx_wr);
			if(u1rx_rd < U1RX_BUF_SIZE-1)
			{
				u1rx_rd++;
				return u1rx_buf[u1rx_rd-1];
			}
			else
			{
				u1rx_rd = 0;
				return u1rx_buf[U1RX_BUF_SIZE-1];
			}
		}
#else
		{
			while(USART_GetFlagStatus(USART1, USART_FLAG_RXNE) == RESET);
			return USART_ReceiveData(USART1);
		}
#endif
	break;

		case PF_USART2:
#if (USART2_RX_INTERRUPT == VAL_ENABLE)
		{
			while(u2rx_rd == u2rx_wr);
			if(u2rx_rd < U2RX_BUF_SIZE-1)
			{
				u2rx_rd++;
				return u2rx_buf[u2rx_rd-1];
			}
			else
			{
				u2rx_rd = 0;
				return u2rx_buf[U2RX_BUF_SIZE-1];
			}
		}
#else
		{
			while(USART_GetFlagStatus(USART2, USART_FLAG_RXNE) == RESET);
			return USART_ReceiveData(USART2);
		}
#endif
		break;

	default:
		return RET_NOK;
	}

	return RET_NOK;
}

int32_t usart_getc_nonblk(platform_usart usart)
{
	switch(usart)
	{
		case PF_USART1:
#if (USART1_RX_INTERRUPT == VAL_ENABLE)
		{
			if(u1rx_rd == u1rx_wr) return RET_NOK;
			if(u1rx_rd < U1RX_BUF_SIZE-1)
			{
				u1rx_rd++;
				return u1rx_buf[u1rx_rd-1];
			}
			else
			{
				u1rx_rd = 0;
				return u1rx_buf[U1RX_BUF_SIZE-1];
			}
		}
#else
		{
		if(USART_GetFlagStatus(USART1, USART_FLAG_RXNE) == RESET) return RET_NOK;
		return USART_ReceiveData(USART1);
		}
#endif
		break;

		case PF_USART2:
#if (USART2_RX_INTERRUPT == VAL_ENABLE)
		{
			if(u2rx_rd == u2rx_wr) return RET_NOK;
			if(u2rx_rd < U2RX_BUF_SIZE-1)
			{
				u2rx_rd++;
				return u2rx_buf[u2rx_rd-1];
			}
			else
			{
				u2rx_rd = 0;
				return u2rx_buf[U2RX_BUF_SIZE-1];
			}
		}
#else
		{
		if(USART_GetFlagStatus(USART2, USART_FLAG_RXNE) == RESET) return RET_NOK;
		return USART_ReceiveData(USART2);
		}
#endif
		break;

		default:
			return RET_NOK;
	}

	return RET_NOK;
}

void usart_gets(platform_usart usart, uint8_t * ch)
{
	while(1)
	{
		*ch = (uint8_t)usart_getc(usart);
		if(*ch == '\n')
		{
			ch++;
			*ch = 0;
			return;
		}

		ch++;
	}
}


/*
int putchar(int ch)
{
	int ret;
	ret = usart_putc(PF_USART1,ch);
	return ret;
}


int getchar(void)
{
	return usart_getc(PF_USART1);
}
*/
