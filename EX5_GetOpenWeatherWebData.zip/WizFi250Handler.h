#ifndef WIZFI250HANDLER_H_
#define WIZFI250HANDLER_H_

#include "type.h"
#include "pltfrm_usart.h"


#endif /* WIZFI250HANDLER_H_ */
