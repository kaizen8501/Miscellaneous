#include "pltfrm_gpio.h"

uint8_t pltfrm_gpio_init(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin, GPIOMode_TypeDef mode)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	GPIO_InitStructure.GPIO_Mode = mode;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin;
	GPIO_Init(GPIOx, &GPIO_InitStructure);

	return 0;
}


uint8_t pltfrm_gpio_set(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin, uint8_t value)
{
	if(value == VAL_HIGH) {
		GPIO_SetBits(GPIOx, GPIO_Pin);
	} else if(value == VAL_LOW) {
		GPIO_ResetBits(GPIOx, GPIO_Pin);
	} else if(value == VAL_TOG) {
		GPIOx->ODR ^= GPIO_Pin;
	} else return RET_NOK;

	return RET_OK;
}

void pltfrm_gpio_write(GPIO_TypeDef* GPIOx, uint16_t value)
{
	GPIO_Write(GPIOx,value);
}

uint8_t pltfrm_gpio_get(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin, int8_t isOutput)
{
	if(isOutput == VAL_OUTPUT)
		return GPIO_ReadOutputDataBit(GPIOx, GPIO_Pin)==Bit_SET? VAL_HIGH: VAL_LOW;
	else return GPIO_ReadInputDataBit(GPIOx, GPIO_Pin)==Bit_SET? VAL_HIGH: VAL_LOW;
}

uint16_t pltfrm_gpio_gets(GPIO_TypeDef* GPIOx, int8_t isOutput)
{
	if(isOutput == VAL_TRUE)
		return GPIO_ReadOutputData(GPIOx);
	else return GPIO_ReadInputData(GPIOx);
}
