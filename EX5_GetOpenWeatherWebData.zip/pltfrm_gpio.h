/*
 * pltfrm_gpio.h
 *
 *  Created on: 2015. 3. 17.
 *      Author: kaizen
 */

#ifndef PLTFRM_GPIO_H_
#define PLTFRM_GPIO_H_

#include "type.h"

uint8_t pltfrm_gpio_init(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin, GPIOMode_TypeDef mode);
uint8_t pltfrm_gpio_set	(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin, uint8_t value);
void	pltfrm_gpio_write(GPIO_TypeDef* GPIOx, uint16_t value);
uint8_t	pltfrm_gpio_get	(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin, int8_t isOutput);
uint16_t pltfrm_gpio_gets(GPIO_TypeDef* GPIOx, int8_t isOutput);
#endif /* PLTFRM_GPIO_H_ */
