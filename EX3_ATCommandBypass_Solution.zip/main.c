#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "stm32f10x.h"
#include "pltfrm_usart.h"

uint8_t WizFi250_BypassMode();

int main()
{
	uint32_t usart_menu;

	platform_init();

	WizFi250_Restart();

	printf("Start AT Command Bypass Example");

	while(1)
	{
		printf("\r\n\r\n//////////////////////////////////////////////////////\r\n");
		printf("// 1 : Bypass mode\r\n");
		printf("//////////////////////////////////////////////////////\r\n\r\n");

		while(1)
		{
			usart_menu = (uint8_t)usart_getc(PF_USART1);
			if ( usart_menu != RET_NOK )	break;
		}
		if( usart_menu == '1')
		{
			WizFi250_BypassMode();	// This function is block
		}
	}
}


uint8_t WizFi250_BypassMode()
{
	int32_t usart_recv;
	printf("\r\nDBG>> Starting Bypass mode.....\r\n");
	printf("\r\nDBG>> If you want to exit this mode, press ESC key\r\n");

	while(1)
	{
		usart_recv = usart_getc_nonblk(PF_USART1);
		if(usart_recv != RET_NOK)
			usart_putc(PF_USART2,(uint8_t)usart_recv);

		usart_recv = usart_getc_nonblk(PF_USART2);
		if(usart_recv != RET_NOK)
		{
			if((uint8_t)usart_recv == 0x1b)	break;
			usart_putc(PF_USART1,(uint8_t)usart_recv);
		}
	}

	return RET_OK;
}


