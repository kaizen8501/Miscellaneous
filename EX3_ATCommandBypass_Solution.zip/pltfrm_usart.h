#ifndef PLTFRM_USART_H_
#define PLTFRM_USART_H_

#include "type.h"
#include "pltfrm.h"
#include "pltfrm_gpio.h"

#define USART1_PORT			GPIOA			///< 1st USART Port
#define USART1_TX_PIN		GPIO_Pin_9		///< 1st USART Tx Pin
#define USART1_RX_PIN		GPIO_Pin_10		///< 1st USART Rx Pin
#define USART1_CTS_PIN		GPIO_Pin_11		///< 1st USART CTS Pin
#define USART1_RTS_PIN		GPIO_Pin_12		///< 1st USART RTS Pin


#define USART2_PORT			GPIOA			///< 2st USART Port
#define USART2_TX_PIN		GPIO_Pin_2		///< 2st USART Tx Pin
#define USART2_RX_PIN		GPIO_Pin_3		///< 2st USART Rx Pin
#define USART2_CTS_PIN		GPIO_Pin_0		///< 2st USART CTS Pin
#define USART2_RTS_PIN		GPIO_Pin_1		///< 2st USART RTS Pin

#define USART1_RX_INTERRUPT VAL_ENABLE
#define USART2_RX_INTERRUPT VAL_ENABLE

typedef enum{
	PF_USART1=1,
	PF_USART2
}platform_usart;

uint8_t usart_init	(platform_usart usart);
int		usart_putc	(platform_usart usart, int ch);
int32_t usart_puts	(platform_usart usart, uint8_t* buf, uint8_t reqSize);
int		usart_getc	(platform_usart usart);
int32_t	usart_getc_nonblk(platform_usart usart);

/*
int		putchar	(int ch);
int		getchar	(void);
*/

#endif /* PLTFRM_USART_H_ */
