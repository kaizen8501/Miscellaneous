#ifndef TYPE_H_
#define TYPE_H_

#include "stm32f10x.h"
#include "stm32f10x_conf.h"
#include "gnrl_fun.h"

#define RET_FAIL	1
#define RET_OK		0
#define RET_NOK		-1

#define VAL_HIGH	1
#define VAL_LOW		0

#define VAL_TOG		2
#define VAL_ON		1
#define VAL_OFF		0

#define VAL_SET		1
#define VAL_CLEAR	0

#define VAL_OUTPUT	1
#define VAL_INPUT	0

#define VAL_TRUE	1
#define VAL_FALSE	0

#define VAL_ENABLE	1
#define VAL_DISABLE	0

#define VAL_NONE	-1
#define VAL_INVALID	-2

#define CRLF	"\r\n"

#endif /* TYPE_H_ */
