#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "stm32f10x.h"
#include "pltfrm_usart.h"

#define SSID 		"wizohp"
#define PASSWORD	"wiznet218"
#define SERVER_PORT	"5000"


int main()
{
	char cmd[256];
	char recv_data[256];
	int32_t idx=0,cr_lf_check=0;
	int32_t uart_recv;

	platform_init();

	WizFi250_Restart();

	if ( send_and_check_command("AT+WLEAVE", 1, 500,  10, "[OK]", "", 1) !=0 )	{ printf("DBG>>> Error : AT Command\r\n");}
	if ( send_and_check_command("AT+WNET=1", 1, 500,  10, "[OK]", "", 1) !=0 )	{ printf("DBG>>> Error : AT Command\r\n");}


	sprintf(cmd,"AT+WSET=0,%s",SSID);
	if ( send_and_check_command(cmd, 1, 500,  10, "[OK]", "", 1) !=0 )			{ printf("DBG>>> Error : AT Command\r\n");}
	sprintf(cmd,"AT+WSEC=0,,%s",PASSWORD);
	if ( send_and_check_command(cmd, 1, 500,  10, "[OK]", "", 1) !=0 )			{ printf("DBG>>> Error : AT Command\r\n");}
	if ( send_and_check_command("AT+WJOIN", 1, 500,  100, "[OK]", "", 1) !=0 )	{ printf("DBG>>> Error : AT Command\r\n");}

	sprintf(cmd,"AT+SCON=O,TSN,,,%s,1",SERVER_PORT);
	if ( send_and_check_command(cmd, 1, 500,  100, "[OK]", "", 1) !=0 )			{ printf("DBG>>> Error : AT Command\r\n");}


	printf("DBG>>> Recv Data\r\n");

	pltfrm_gpio_init(GPIOA,(GPIO_Pin_0 | GPIO_Pin_1),GPIO_Mode_Out_PP);
	pltfrm_gpio_set(GPIOA,(GPIO_Pin_0 | GPIO_Pin_1),1);

	while(1)
	{
		usart_gets(PF_USART2,&recv_data);

		if( strcmp(recv_data,"TURN ON LED0\r\n") == 0 )			pltfrm_gpio_set(GPIOA,GPIO_Pin_0,0);
		else if( strcmp(recv_data, "TURN OFF LED0\r\n") == 0)	pltfrm_gpio_set(GPIOA,GPIO_Pin_0,1);
		else if( strcmp(recv_data, "TURN ON LED1\r\n") == 0 )	pltfrm_gpio_set(GPIOA,GPIO_Pin_1,0);
		else if( strcmp(recv_data, "TURN OFF LED1\r\n") == 0 )	pltfrm_gpio_set(GPIOA,GPIO_Pin_1,1);

		usart_puts(PF_USART1,recv_data,strlen(recv_data));
		usart_puts(PF_USART2,recv_data,strlen(recv_data));
	}
}
