#ifndef PLTFRM_H_
#define PLTFRM_H_

#include "type.h"

void RCC_Configuration	(void);
void NVIC_Configuration	(void);
void GPIO_Configuration	(void);


uint8_t platform_init();


#endif /* PLTFRM_H_ */
