#include "gnrl_fun.h"


void delay_us(const uint32_t usec)
{
	RCC_ClocksTypeDef RCC_Clocks;

	/* Configure HCLK clock as SysTick clock source */
	SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK);

	RCC_GetClocksFreq(&RCC_Clocks);

	SysTick_Config(usec * (RCC_Clocks.HCLK_Frequency / 1000000));

	SysTick->CTRL &= ~SysTick_CTRL_TICKINT_Msk;

	while (!(SysTick->CTRL & SysTick_CTRL_COUNTFLAG_Msk));
}

void delay_ms (const uint32_t msec)
{
    int i;
	for(i=0; i<msec; i++)
	    delay_us(1000);
}

