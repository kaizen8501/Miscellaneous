#include "WizFi250Handler.h"
#include "stm32f10x_gpio.h"

#define BUFF_LEN 1024
uint8_t  g_wizfi250_resp_buff[BUFF_LEN]={0,};
uint32_t g_resp_data_len=0;

uint8_t send_and_check_command(char* send_command, uint8_t cr_lf, uint32_t check_delay, uint32_t check_count, char* str_find1, char* str_find2, uint8_t debug_print)
{
	uint32_t i;
	uint8_t is_found1=0, is_found2=0;
	uint32_t nResult = 0;
	int8_t ch;
	char crlf_string[3];

	g_resp_data_len = 0;

	// Send Command
	usart_puts(PF_USART2,(uint8_t*)send_command,strlen(send_command));

	// Send CR, LF
	if ( cr_lf==1 )		strcpy(crlf_string, "\r");
	else if ( cr_lf==2 )	strcpy(crlf_string, "\n");
	else if ( cr_lf==3 )	strcpy(crlf_string, "\r\n");
	if ( cr_lf==1 || cr_lf==2 || cr_lf==3 )
	{
		usart_puts(PF_USART2,(uint8_t*)crlf_string,strlen(crlf_string));
	}

	if ( debug_print==1 )	printf("\r\nDBG>>> Send : %s\r\n", send_command);
	// Recv Response
	if ( str_find1==0 ) is_found1 = 1;
	if ( str_find2==0 ) is_found2 = 1;
	printf("\r\nDBG>>> Resp Recv \r\n");

	for(i=0;i<check_count;i++)
	{
		do{
			ch = usart_getc_nonblk(PF_USART2);
			if(ch != RET_NOK)
				g_wizfi250_resp_buff[g_resp_data_len++] = (uint8_t)ch;
			if(ch == '\n')
				break;

		}while(ch != RET_NOK);
		g_wizfi250_resp_buff[g_resp_data_len]='\0';

		if ( is_found1==0 )
		{
			if ( strstr((char*)g_wizfi250_resp_buff, str_find1) ) is_found1 = 1;
		}
		if ( is_found2==0 )
		{
			if ( strstr((char*)g_wizfi250_resp_buff, str_find2) ) is_found2 = 1;
		}

		if ( debug_print==1 )	printf("%s", g_wizfi250_resp_buff);
		g_resp_data_len = 0;

		if( is_found1 == is_found2 ) break;

		delay_ms(check_delay);
	}


	// Error : Timeout or Not Found Success String
	if ( !(is_found1 && is_found2) )
	{
		printf("DBG>>> Error : Timeout or Not Found Success String\r\n");
		nResult = 2;
		return nResult;
	}


	return nResult;
}


void WizFi250_Restart()
{
	uint8_t ch;

	pltfrm_gpio_set(GPIOA, GPIO_Pin_8, 1);		// HIGH
	delay_ms(10);
	pltfrm_gpio_set(GPIOA, GPIO_Pin_8, 0);		// LOW
	delay_ms(10);
	pltfrm_gpio_set(GPIOA, GPIO_Pin_8, 1);		// HIGH

	delay_ms(1000);
}

void WizFi250_FactoryReset ()
{
	int i;
	pltfrm_gpio_set(GPIOC, GPIO_Pin_10, 1);	// HIGH
	delay_ms(200);

	for(i=0;i<3;i++)
	{
		pltfrm_gpio_set(GPIOC, GPIO_Pin_10, 0);// LOW
		delay_ms(200);
		pltfrm_gpio_set(GPIOC, GPIO_Pin_10, 1);// HIGH
		delay_ms(200);
	}
}
