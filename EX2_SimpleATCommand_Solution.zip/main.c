#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "stm32f10x.h"
#include "pltfrm_usart.h"

#define SSID 		"wizohp"
#define PASSWORD	"wiznet218"
#define SERVER_PORT	"5000"


int main()
{
	char cmd[256];
	int32_t uart_recv;

	platform_init();

	WizFi250_Restart();

	if ( send_and_check_command("AT+WLEAVE", 1, 500,  10, "[OK]", "", 1) !=0 )	{ printf("DBG>>> Error : AT Command\r\n");}
	if ( send_and_check_command("AT+WNET=1", 1, 500,  10, "[OK]", "", 1) !=0 )	{ printf("DBG>>> Error : AT Command\r\n");}


	sprintf(cmd,"AT+WSET=0,%s",SSID);
	if ( send_and_check_command(cmd, 1, 500,  10, "[OK]", "", 1) !=0 )			{ printf("DBG>>> Error : AT Command\r\n");}
	sprintf(cmd,"AT+WSEC=0,,%s",PASSWORD);
	if ( send_and_check_command(cmd, 1, 500,  10, "[OK]", "", 1) !=0 )			{ printf("DBG>>> Error : AT Command\r\n");}
	if ( send_and_check_command("AT+WJOIN", 1, 500,  100, "[OK]", "", 1) !=0 )	{ printf("DBG>>> Error : AT Command\r\n");}

	sprintf(cmd,"AT+SCON=O,TSN,,,%s,1",SERVER_PORT);
	if ( send_and_check_command(cmd, 1, 500,  100, "[OK]", "", 1) !=0 )			{ printf("DBG>>> Error : AT Command\r\n");}


	printf("DBG>>> Recv Data\r\n");
	while(1)
	{
		uart_recv = usart_getc(PF_USART2);
		usart_putc(PF_USART2,uart_recv);
	}
}

