#ifndef GNRL_FUN_H_
#define GNRL_FUN_H_


#include "type.h"

void delay_us(const uint32_t usec);
void delay_ms (const uint32_t msec);


#endif /* GNRL_FUN_H_ */
