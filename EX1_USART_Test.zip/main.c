#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "stm32f10x.h"

void RCC_Configuration(void);
void GPIO_Configuration(void);


void RCC_Configuration(void)
{
	ErrorStatus HSEStartUpStatus;

	RCC_DeInit();					/* RCC system reset(for debug purpose) */
	RCC_HSEConfig(RCC_HSE_ON);			/* Enable HSE */
	HSEStartUpStatus = RCC_WaitForHSEStartUp();	/* Wait till HSE is ready */

	if(HSEStartUpStatus == SUCCESS)
	{
		FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);	/* Enable Prefetch Buffer */
		FLASH_SetLatency(FLASH_Latency_2);	/* Flash 2 wait state */
		RCC_HCLKConfig(RCC_SYSCLK_Div1);	/* HCLK = SYSCLK */
		RCC_PCLK2Config(RCC_HCLK_Div1);		/* PCLK2 = HCLK */
		RCC_PCLK1Config(RCC_HCLK_Div2);		/* PCLK1 = HCLK/2 */
		RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_9);	/* PLLCLK = 8MHz * 9 = 72 MHz */
		RCC_PLLCmd(ENABLE);	/* Enable PLL */

		while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET) {}	/* Wait till PLL is ready */
		RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);	/* Select PLL as system clock source */
		while(RCC_GetSYSCLKSource() != 0x08) {}		/* Wait till PLL is used as system clock source */
	}

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOC |
					   RCC_APB2Periph_AFIO, ENABLE);

	/* Disable the Serial Wire Jtag Debug Port SWJ-DP */
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_Disable, ENABLE);
	AFIO->MAPR |= 0x04000000;


//	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);
//	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE, ENABLE);
//	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOF, ENABLE);
}

void GPIO_Configuration(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	//GPIO_StructInit(&GPIO_InitStructure);	// Set all as default

	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_All;

	GPIO_Init(GPIOA, &GPIO_InitStructure);
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	GPIO_Init(GPIOC, &GPIO_InitStructure);
}

uint8_t UartPutc(uint8_t ch)
{
	USART_SendData(USART1, (uint8_t)ch);
	while(USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);

	return (ch);
}

// Uart string output
 void   UartPuts   (uint8_t * mytext)
 {
     //unsigned char CurrChar;
     do {
    	 if(*mytext !=(uint8_t)0x0){
    		 UartPutc(*mytext);
    	 }
    	 mytext++;
     }while(*mytext != (uint8_t)0x0);

//    	 CurrChar = *mytext;
//         if (CurrChar != (char) 0x0) {
//             UartPutc(CurrChar);  // Normal data
//         }
//         *mytext++;
//     } while (CurrChar != 0);
     return;
}

int main()
{
	USART_InitTypeDef USART_InitStructure;
	GPIO_InitTypeDef GPIO_InitStructure;


	RCC_Configuration();
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);
	GPIO_Configuration();

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);


	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;			// USART1_TX_PIN
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;			// USART1_RX_PIN
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	USART_Cmd(USART1, DISABLE);
	USART_InitStructure.USART_BaudRate		= 115200;
	USART_InitStructure.USART_WordLength	= USART_WordLength_8b;
	USART_InitStructure.USART_StopBits		= USART_StopBits_1;
	USART_InitStructure.USART_Parity		= USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl	= USART_HardwareFlowControl_None;

	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_Init(USART1, &USART_InitStructure);
	USART_Cmd(USART1, ENABLE);

	UartPuts ((uint8_t*)"Test Example 1\r\n");
}

